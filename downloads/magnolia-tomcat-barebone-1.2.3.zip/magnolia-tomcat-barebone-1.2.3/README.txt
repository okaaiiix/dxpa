===========================================================

                                       _ _
     _ __ ___   __ _  __ _ _ __   ___ | (_) __ _  (R)
    | '_ ` _ \ / _` |/ _` | '_ \ / _ \| | |/ _` |
    | | | | | | (_| | (_| | | | | (_) | | | (_| |
    |_| |_| |_|\__,_|\__, |_| |_|\___/|_|_|\__,_|
                     |___/


        10. November 2020
        v 1.2.3
        Community Edition

        http://www.magnolia-cms.com/

===========================================================

Magnolia-ready and configured Apache Tomcat

This package contains:

   Apache Tomcat 9.0.39


===========================================================
Installation
===========================================================

Installation instructions can be found at:
    http://documentation.magnolia-cms.com/DOCS/Installing+Magnolia


===========================================================
Documentation, Licensing & Support
===========================================================

You can find documentation at:
    http://documentation.magnolia-cms.com/

Feel free to join the community and contribute through
bug reports, documentation, discussions, and more to help
improve Magnolia!
    http://www.magnolia-cms.com/developers.html

For details on commercial services and support regarding
Magnolia, please visit:
    http://www.magnolia-cms.com/services.html

THIS SOFTWARE IS PROVIDED "AS-IS" AND FREE OF CHARGE, WITH
ABSOLUTELY NO WARRANTY OR SUPPORT OF ANY KIND, EXPRESSED OR
IMPLIED, UNDER THE TERMS OF THE INCLUDED LICENSE AGREEMENT.

Thank you for using Magnolia.

Magnolia International Ltd.
info@magnolia-cms.com


===========================================================

Copyright 2020 Magnolia International Ltd.

Magnolia is a registered trademark of
Magnolia International Ltd.

http://www.magnolia-cms.com
All rights reserved.
